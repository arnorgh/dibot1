import { createClient } from "@supabase/supabase-js";
import { ENV } from "../utils/env.js";

export const supabase = createClient(ENV.SUPABASE_URL, ENV.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
  global: { headers: { "x-client": "discord-bot" } },
});

export type GuildConfig = {
  id: string;
  guild_id: string;
  guild_name: string;
  prefix: string | null;
  welcome_message: string | null;
  moderation_enabled: boolean;
  auto_role_id: string | null;
  mod_log_channel_id: string | null;
  settings: Record<string, unknown> | null;
  updated_at: string;
};

export async function upsertDiscordGuild(payload: {
  id: string;
  name: string;
  icon: string | null;
  member_count: number;
  bot_permissions: string;
  is_active?: boolean;
}): Promise<void> {
  const { error } = await supabase
    .from("discord_guilds")
    .upsert({
      id: payload.id,
      name: payload.name,
      icon: payload.icon,
      member_count: payload.member_count,
      bot_permissions: payload.bot_permissions,
      is_active: payload.is_active ?? true,
      last_seen: new Date().toISOString(),
      joined_at: new Date().toISOString(),
    }, { onConflict: "id" });
  if (error) throw error;
}

export async function fetchGuildConfig(guildId: string): Promise<GuildConfig | null> {
  const { data, error } = await supabase
    .from("guild_configs")
    .select("*")
    .eq("guild_id", guildId)
    .maybeSingle();
  if (error) throw error;
  return data as GuildConfig | null;
}

export async function fetchEnabledPlugins(guildId: string) {
  const { data, error } = await supabase
    .from("bot_plugins")
    .select("id,name,description,version,is_enabled,config")
    .eq("is_enabled", true);
  if (error) throw error;
  return data ?? [];
}

export async function incrementCommandUsage(name: string, guildId: string | null) {
  try {
    const { error } = await supabase
      .from("bot_commands")
      .update({ usage_count: (null as any) })
      .eq("name", name)
      .is("guild_id", guildId);
    if (error) { /* ignore; analytics via logs instead */ }
  } catch {}
}

export async function logCommandExecution(entry: {
  command_name: string;
  user_id: string;
  username: string;
  guild_id: string | null;
  success: boolean;
  error_message?: string | null;
}) {
  const { error } = await supabase.from("command_logs").insert({
    ...entry,
    executed_at: new Date().toISOString(),
  });
  if (error) throw error;
}

export async function updateBotStatus(status: Partial<{ name: string; status: string; total_commands: number; total_servers: number; uptime_start: string }>) {
  const { error } = await supabase
    .from("bot_config")
    .upsert({ id: 1, ...status, updated_at: new Date().toISOString() }, { onConflict: "id" });
  if (error) throw error;
}

export type DBCommand = {
  id: string;
  name: string;
  description: string;
  category: string;
  is_enabled: boolean;
  guild_id: string | null;
  guild_specific_config: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
};

export async function fetchCommandsForGuild(guildId: string | null): Promise<DBCommand[]> {
  const q = supabase.from("bot_commands").select("*").eq("is_enabled", true);
  if (guildId) (q as any).in("guild_id", [guildId, null]); else (q as any).is("guild_id", null);
  const { data, error } = await q;
  if (error) throw error;
  return data as DBCommand[];
}
