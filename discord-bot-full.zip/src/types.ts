export type Category = "general" | "moderation" | "admin" | "fun" | "utility";
