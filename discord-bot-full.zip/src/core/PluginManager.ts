import type { Client } from "discord.js";
import { fetchEnabledPlugins } from "../database/supabase.js";
import type { Plugin, PluginContext } from "./Plugin.js";

export class PluginManager {
  private loaded = new Map<string, Plugin[]>();

  constructor(private client: Client) {}

  async loadForGuild(guildId: string) {
    const plugins = await fetchEnabledPlugins(guildId);
    const impls: Plugin[] = plugins.map((p) => ({
      name: p.name,
      version: p.version ?? "1.0.0",
      onLoad: async () => {},
    }));
    this.loaded.set(guildId, impls);
    for (const plugin of impls) {
      const ctx: PluginContext = { guildId, config: null };
      await plugin.onLoad(this.client, ctx);
    }
  }

  async unloadForGuild(guildId: string) {
    const list = this.loaded.get(guildId) ?? [];
    for (const plugin of list) {
      const ctx: PluginContext = { guildId, config: null };
      await plugin.onUnload?.(this.client, ctx);
    }
    this.loaded.delete(guildId);
  }

  async reloadForGuild(guildId: string) {
    await this.unloadForGuild(guildId);
    await this.loadForGuild(guildId);
  }
}
