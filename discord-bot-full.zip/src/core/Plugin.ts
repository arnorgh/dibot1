import type { Client } from "discord.js";

export interface PluginContext {
  guildId: string;
  config: Record<string, unknown> | null;
}

export interface Plugin {
  name: string;
  version: string;
  onLoad: (client: Client, ctx: PluginContext) => Promise<void>;
  onUnload?: (client: Client, ctx: PluginContext) => Promise<void>;
}
