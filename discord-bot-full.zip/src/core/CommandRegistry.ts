import { TTLCache } from "../utils/cache.js";
import { fetchCommandsForGuild } from "../database/supabase.js";
import type { Command } from "./Command.js";
import { help } from "../commands/general/help.js";
import { ping } from "../commands/general/ping.js";
import { info } from "../commands/general/info.js";
import { showConfig } from "../commands/admin/config.js";
import { moderationBundle } from "../moderation/index.js";

export class CommandRegistry {
  private cache = new TTLCache<string, Map<string, Command>>(60_000);

  private builtins(): Map<string, Command> {
    const map = new Map<string, Command>();
    [help, ping, info, showConfig, ...moderationBundle].forEach((c) => map.set(c.name, c));
    return map;
  }

  async load(guildId: string | null): Promise<Map<string, Command>> {
    const k = guildId ?? "global";
    const cached = this.cache.get(k);
    if (cached) return cached;

    const registry = this.builtins();
    const dbCommands = await fetchCommandsForGuild(guildId);
    for (const dbc of dbCommands) {
      registry.set(dbc.name, {
        name: dbc.name,
        description: dbc.description,
        category: (dbc.category as any) ?? "utility",
        usage: `${dbc.name}`,
        run: async (msg, args) => {
          await msg.reply(`Command **${dbc.name}** executed with args: ${args.join(" ") || "(none)"}`);
        },
      });
    }
    this.cache.set(k, registry);
    return registry;
  }

  invalidate(guildId: string | null) {
    this.cache.del(guildId ?? "global");
  }
}
