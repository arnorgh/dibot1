import type { Message } from "discord.js";
import type { Category } from "../types.js";

export interface CommandContext {
  prefix: string;
  guildId: string | null;
}

export interface Command {
  name: string;
  description: string;
  category: Category;
  usage?: string;
  run: (msg: Message, args: string[], ctx: CommandContext) => Promise<void>;
}
