import { Client, GatewayIntentBits, Partials } from "discord.js";
import { ENV } from "./utils/env.js";
import { log } from "./utils/logger.js";
import { onReady } from "./events/ready.js";
import { onGuildCreate } from "./events/guildCreate.js";
import { onGuildDelete } from "./events/guildDelete.js";
import { onMessageCreate } from "./events/messageCreate.js";
import { subscribeRealtime } from "./services/realtime.js";
import { CommandRegistry } from "./core/CommandRegistry.js";
import { PluginManager } from "./core/PluginManager.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel, Partials.GuildMember, Partials.Message, Partials.User],
});

const registry = new CommandRegistry();
const pluginManager = new PluginManager(client);

client.once("ready", () => onReady(client));
client.on("guildCreate", onGuildCreate);
client.on("guildDelete", onGuildDelete);
client.on("messageCreate", onMessageCreate);
client.on("guildMemberAdd", async (m) => (await import("./events/guildMemberAdd.js")).onGuildMemberAdd(m));

if (ENV.SUPABASE_REALTIME) {
  subscribeRealtime(async (topic, payload) => {
    log.info("Realtime change", { topic, payload: { schema: payload.schema, table: payload.table, type: payload.eventType } });
    if (topic === "guild_configs") {
      const guildId = payload.new?.guild_id ?? payload.old?.guild_id;
      if (guildId) {
        registry.invalidate(guildId);
        await pluginManager.reloadForGuild(guildId);
      }
    }
    if (topic === "bot_commands") {
      const guildId = payload.new?.guild_id ?? payload.old?.guild_id ?? null;
      registry.invalidate(guildId);
    }
    if (topic === "bot_plugins") {
      const guildId = payload.new?.guild_id ?? payload.old?.guild_id;
      if (guildId) await pluginManager.reloadForGuild(guildId);
    }
  });
}

client.login(ENV.DISCORD_BOT_TOKEN).catch((e) => {
  log.error("Failed to login", { err: String(e) });
  process.exit(1);
});

process.on("SIGINT", async () => {
  try { await client.destroy(); } finally { process.exit(0); }
});
process.on("SIGTERM", async () => {
  try { await client.destroy(); } finally { process.exit(0); }
});
