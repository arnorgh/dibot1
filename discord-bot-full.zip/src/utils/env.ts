import "dotenv/config";

function get(name: string, required = true): string | undefined {
  const v = process.env[name];
  if (!v && required) throw new Error(`Missing env: ${name}`);
  return v;
}

export const ENV = {
  DISCORD_BOT_TOKEN: get("DISCORD_BOT_TOKEN")!,
  SUPABASE_URL: get("SUPABASE_URL")!,
  SUPABASE_SERVICE_ROLE_KEY: get("SUPABASE_SERVICE_ROLE_KEY")!,
  NODE_ENV: get("NODE_ENV", false) ?? "development",
  SUPABASE_REALTIME: (get("SUPABASE_REALTIME", false) ?? "true").toLowerCase() != "false",
  EDGE_FN_BOT_STATUS: get("EDGE_FN_BOT_STATUS", false) ?? "discord-bot-status",
  EDGE_FN_SEND_MESSAGE: get("EDGE_FN_SEND_MESSAGE", false) ?? "discord-send-message",
  EDGE_FN_GUILD_MANAGEMENT: get("EDGE_FN_GUILD_MANAGEMENT", false) ?? "guild-management",
};
