export class TTLCache<K, V> {
  private store = new Map<K, { v: V; exp: number }>();
  constructor(private ttlMs = 30_000) {}
  get(key: K): V | undefined {
    const item = this.store.get(key);
    if (!item) return undefined;
    if (Date.now() > item.exp) {
      this.store.delete(key);
      return undefined;
    }
    return item.v;
  }
  set(key: K, value: V) {
    this.store.set(key, { v: value, exp: Date.now() + this.ttlMs });
  }
  del(key: K) {
    this.store.delete(key);
  }
  clear() {
    this.store.clear();
  }
}
