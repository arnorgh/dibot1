import { ENV } from "../utils/env.js";

export async function callEdgeFunction<T=unknown>(name: string, body: any): Promise<T> {
  const url = `${ENV.SUPABASE_URL}/functions/v1/${name}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ENV.SUPABASE_SERVICE_ROLE_KEY}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Edge function ${name} failed: ${res.status}`);
  return (await res.json()) as T;
}
