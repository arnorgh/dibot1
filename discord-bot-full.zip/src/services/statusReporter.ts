import type { Client } from "discord.js";
import cron from "node-cron";
import { updateBotStatus } from "../database/supabase.js";
import { log } from "../utils/logger.js";

export function scheduleStatusReporter(client: Client) {
  const start = new Date();
  cron.schedule("*/1 * * * *", async () => {
    try {
      await updateBotStatus({
        name: client.user?.username,
        status: "online",
        total_servers: client.guilds.cache.size,
        total_commands: 0,
        uptime_start: start.toISOString(),
      });
    } catch (e) {
      log.warn("Failed to update status", { err: String(e) });
    }
  });
}
