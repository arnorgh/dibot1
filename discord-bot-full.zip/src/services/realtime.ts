import { supabase } from "../database/supabase.js";
import { log } from "../utils/logger.js";

export function subscribeRealtime(onChange: (topic: string, payload: any) => void) {
  const channel = supabase.channel("bot-realtime");

  channel.on("postgres_changes", { event: "UPDATE", schema: "public", table: "guild_configs" }, (p) => {
    onChange("guild_configs", p);
  });
  channel.on("postgres_changes", { event: "INSERT", schema: "public", table: "bot_commands" }, (p) => onChange("bot_commands", p));
  channel.on("postgres_changes", { event: "UPDATE", schema: "public", table: "bot_commands" }, (p) => onChange("bot_commands", p));
  channel.on("postgres_changes", { event: "DELETE", schema: "public", table: "bot_commands" }, (p) => onChange("bot_commands", p));

  channel.on("postgres_changes", { event: "UPDATE", schema: "public", table: "bot_plugins" }, (p) => onChange("bot_plugins", p));

  channel.subscribe((s) => {
    log.info("Realtime subscription state", { s });
  });

  return () => {
    supabase.removeChannel(channel);
  };
}
