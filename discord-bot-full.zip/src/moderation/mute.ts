import type { Command } from "../core/Command.js";
import { PermissionFlagsBits } from "discord.js";

export const mute: Command = {
  name: "mute",
  description: "Timeout a member (mute)",
  category: "moderation",
  usage: "mute @user [minutes] [reason]",
  async run(msg, args) {
    if (!msg.member?.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return void msg.reply("You need Moderate Members permission.");
    }
    const member = msg.mentions.members?.first();
    if (!member) return void msg.reply("Mention a user to mute.");
    const minutes = Number(args[1] ?? 10);
    const reason = args.slice(2).join(" ") || "Muted";
    const ms = Math.max(60_000, Math.min(28 * 24 * 60 * 60_000, minutes * 60_000));
    await member.timeout(ms, reason);
    await msg.reply(`Muted ${member.user.tag} for ${Math.round(ms/60000)}m: ${reason}`);
  },
};
