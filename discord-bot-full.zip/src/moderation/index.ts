import { kick } from "./kick.js";
import { ban } from "./ban.js";
import { mute } from "./mute.js";

export const moderationBundle = [kick, ban, mute];
