import type { Command } from "../core/Command.js";
import { PermissionFlagsBits } from "discord.js";

export const ban: Command = {
  name: "ban",
  description: "Ban a member",
  category: "moderation",
  usage: "ban @user [reason]",
  async run(msg, args) {
    if (!msg.member?.permissions.has(PermissionFlagsBits.BanMembers)) {
      return void msg.reply("You need Ban Members permission.");
    }
    const member = msg.mentions.members?.first();
    if (!member) return void msg.reply("Mention a user to ban.");
    const reason = args.slice(1).join(" ") || "No reason";
    await member.ban({ reason });
    await msg.reply(`Banned ${member.user.tag}: ${reason}`);
  },
};
