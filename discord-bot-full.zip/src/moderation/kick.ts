import type { Command } from "../core/Command.js";
import { PermissionFlagsBits } from "discord.js";

export const kick: Command = {
  name: "kick",
  description: "Kick a member",
  category: "moderation",
  usage: "kick @user [reason]",
  async run(msg, args) {
    if (!msg.member?.permissions.has(PermissionFlagsBits.KickMembers)) {
      return void msg.reply("You need Kick Members permission.");
    }
    const member = msg.mentions.members?.first();
    if (!member) return void msg.reply("Mention a user to kick.");
    const reason = args.slice(1).join(" ") || "No reason";
    await member.kick(reason);
    await msg.reply(`Kicked ${member.user.tag}: ${reason}`);
  },
};
