import type { Client } from "discord.js";
import { scheduleStatusReporter } from "../services/statusReporter.js";
import { upsertDiscordGuild } from "../database/supabase.js";
import { log } from "../utils/logger.js";

export async function onReady(client: Client) {
  log.info("Bot ready", { user: client.user?.tag });
  scheduleStatusReporter(client);

  for (const [id, g] of client.guilds.cache) {
    const me = g.members.me;
    await upsertDiscordGuild({
      id,
      name: g.name,
      icon: g.iconURL(),
      member_count: g.memberCount ?? 0,
      bot_permissions: String(me?.permissions?.bitfield ?? 0n),
      is_active: true,
    });
  }
}
