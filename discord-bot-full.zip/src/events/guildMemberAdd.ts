import type { GuildMember } from "discord.js";
import { fetchGuildConfig } from "../database/supabase.js";

export async function onGuildMemberAdd(member: GuildMember) {
  const cfg = await fetchGuildConfig(member.guild.id);

  if (cfg?.welcome_message) {
    const system = member.guild.systemChannel;
    await system?.send(cfg.welcome_message.replace("{user}", `<@${member.id}>`));
  }

  if (cfg?.auto_role_id) {
    const role = member.guild.roles.cache.get(cfg.auto_role_id);
    if (role) await member.roles.add(role, "Auto role assignment");
  }
}
