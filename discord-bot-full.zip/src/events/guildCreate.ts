import type { Guild } from "discord.js";
import { upsertDiscordGuild } from "../database/supabase.js";

export async function onGuildCreate(guild: Guild) {
  const me = guild.members.me;
  await upsertDiscordGuild({
    id: guild.id,
    name: guild.name,
    icon: guild.iconURL(),
    member_count: guild.memberCount ?? 0,
    bot_permissions: String(me?.permissions?.bitfield ?? 0n),
    is_active: true,
  });
}
