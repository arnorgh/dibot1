import type { Guild } from "discord.js";
import { upsertDiscordGuild } from "../database/supabase.js";

export async function onGuildDelete(guild: Guild) {
  await upsertDiscordGuild({
    id: guild.id,
    name: guild.name,
    icon: guild.iconURL(),
    member_count: guild.memberCount ?? 0,
    bot_permissions: "0",
    is_active: false,
  });
}
