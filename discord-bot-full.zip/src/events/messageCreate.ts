import type { Message } from "discord.js";
import { CommandRegistry } from "../core/CommandRegistry.js";
import { fetchGuildConfig, logCommandExecution } from "../database/supabase.js";
import { RateLimiter } from "../utils/rateLimit.js";

const registry = new CommandRegistry();
const limiter = new RateLimiter();

async function getPrefix(guildId: string | null): Promise<string> {
  if (!guildId) return "!";
  const cfg = await fetchGuildConfig(guildId);
  return cfg?.prefix ?? "!";
}

export async function onMessageCreate(msg: Message) {
  if (msg.author.bot) return;
  const guildId = msg.guild?.id ?? null;
  const prefix = await getPrefix(guildId);

  if (!msg.content.startsWith(prefix)) return;
  if (!limiter.allow(`${msg.author.id}:${guildId ?? "dm"}`)) return void msg.react("⏳");

  const args = msg.content.slice(prefix.length).trim().split(/\s+/);
  const name = args.shift()?.toLowerCase() ?? "";

  const commands = await registry.load(guildId);
  const cmd = commands.get(name);
  if (!cmd) return;

  try {
    await cmd.run(msg, args, { prefix, guildId });
    await logCommandExecution({
      command_name: cmd.name,
      user_id: msg.author.id,
      username: msg.author.tag,
      guild_id: guildId,
      success: true,
    });
  } catch (e: any) {
    await msg.reply(`Error: ${e.message ?? String(e)}`);
    await logCommandExecution({
      command_name: cmd.name,
      user_id: msg.author.id,
      username: msg.author.tag,
      guild_id: guildId,
      success: false,
      error_message: String(e),
    });
    registry.invalidate(guildId);
  }
}
