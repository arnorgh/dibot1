import type { Command } from "../../core/Command.js";
import { fetchGuildConfig } from "../../database/supabase.js";

export const showConfig: Command = {
  name: "config",
  description: "Show current guild configuration",
  category: "admin",
  async run(msg) {
    const guildId = msg.guild?.id;
    if (!guildId) return void msg.reply("Guild-only.");
    const cfg = await fetchGuildConfig(guildId);
    await msg.reply(
      "```json\n" + JSON.stringify(cfg ?? {}, null, 2) + "\n```"
    );
  },
};
