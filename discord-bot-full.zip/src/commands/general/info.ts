import type { Command } from "../../core/Command.js";

export const info: Command = {
  name: "info",
  description: "Bot and server info",
  category: "general",
  async run(msg) {
    const guild = msg.guild;
    await msg.reply(
      `Server: ${guild?.name ?? "DM"} | Members: ${guild?.memberCount ?? "n/a"}`
    );
  },
};
