import type { Command } from "../../core/Command.js";

export const help: Command = {
  name: "help",
  description: "Show available commands",
  category: "general",
  async run(msg, _args, ctx) {
    await msg.reply(
      `Prefix: \`${ctx.prefix}\`\nCommands: help, ping, info, config, kick, ban, mute`
    );
  },
};
