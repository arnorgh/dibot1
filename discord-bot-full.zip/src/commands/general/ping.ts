import type { Command } from "../../core/Command.js";

export const ping: Command = {
  name: "ping",
  description: "Latency check",
  category: "general",
  async run(msg) {
    const sent = await msg.reply("Pinging...");
    const latency = sent.createdTimestamp - msg.createdTimestamp;
    await sent.edit(`Pong! ${latency}ms`);
  },
};
