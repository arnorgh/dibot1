# Discord Bot — Supabase Integrated (Node.js + TypeScript)

This is a production-ready baseline that matches the canvas spec: Discord.js v14, realtime hot-reload from Supabase, modular commands/plugins, logging, and Pterodactyl/Pelican deployment.

## Quick start
```bash
pnpm i
pnpm dev
# or
pnpm build && node dist/index.js
```
